package com.rite.products.cloudconnector.security;

import java.sql.Connection;
import java.util.Properties;

import org.apache.log4j.Logger;

import oracle.jdbc.pool.OracleDataSource;

public class DataSourceUtil {
	static final Logger log = Logger.getLogger(DataSourceUtil.class);

	public static Connection createConnection() throws Exception {
		log.info("Start of createConnection ##");
		Connection con = null;
		try {
			Properties props = LoginCreateDataModelHelper.loadProperties();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			OracleDataSource dataSource = new OracleDataSource();
			dataSource.setServerName(props.getProperty("datasource.hostname"));
			dataSource.setUser(props.getProperty("datasource.username"));
			dataSource.setPassword(props.getProperty("datasource.password"));
			dataSource.setDatabaseName(props.getProperty("datasource.name"));
			dataSource.setPortNumber(Integer.valueOf(props.getProperty("datasource.port")));
			dataSource.setDriverType("thin");
			con = dataSource.getConnection();
		} catch (Exception e) {
			throw new Exception();
		}
		return con;
	}
	
	

}
