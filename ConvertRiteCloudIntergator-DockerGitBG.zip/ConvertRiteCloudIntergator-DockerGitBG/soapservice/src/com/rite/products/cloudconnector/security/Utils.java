package com.rite.products.cloudconnector.security;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.activation.DataHandler;

import org.apache.log4j.Logger;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import com.rite.products.cloudconnector.catalog.CatalogServiceStub;

public class Utils {

	static final Logger log = Logger.getLogger(Utils.class);

	public static String generateDynamicSqlQuery(String dynamicSqlQuery, CatalogServiceStub catalogStub, String soapUrl,
			String loginResponseToken) throws Exception {
		log.info("Start of generateDynamicSqlQuery Method ::::");
		String tempDataModelUrl = "";
		String tableName = "";
		String tempCreateReportResponse = "";
		try {
			dynamicSqlQuery = dynamicSqlQuery.toUpperCase();
			String subQuery = dynamicSqlQuery.substring(dynamicSqlQuery.lastIndexOf("FROM"), dynamicSqlQuery.length());
			System.out.println("subQuery######" + subQuery);

			// retrieve TableName from query
			Pattern p = Pattern.compile(
					"from\\s+(?:\\w+\\.)*(\\w+)($|\\s+[WHERE,JOIN,START\\s+WITH,ORDER\\s+BY,GROUP\\s+BY])",
					Pattern.CASE_INSENSITIVE);
			Matcher m = p.matcher(dynamicSqlQuery);
			if (m.find())
				tableName = m.group(1);

			String modifiedSqlQuery = "SELECT C.COLUMN_ID, C.COLUMN_NAME FROM ALL_TAB_COLS C WHERE C.TABLE_NAME = '"
					+ tableName + "'";
			System.out.println("dynamicSqlQuery:::::::::" + dynamicSqlQuery);
			UUID uuid = UUID.randomUUID();
			String tempRequestId = uuid.toString();
			System.out.println("tempRequestId:::" + tempRequestId);

			// Service call for creating Data Model
			tempDataModelUrl = LoginCreateDataModelHelper.createDataModel(catalogStub, tempRequestId,
					loginResponseToken, modifiedSqlQuery);

			log.info("tempDataModelUrl:::::" + tempDataModelUrl);

			// Service call for creating report
			tempCreateReportResponse = ReportHelper.createReportService(soapUrl, loginResponseToken, tempRequestId,
					tempDataModelUrl);
			log.info("tempCreateReportResponse:::::::::::" + tempCreateReportResponse);

			// service call to RunReport
			DataHandler dt = ReportHelper.runReport(soapUrl, loginResponseToken, tempCreateReportResponse);
			String xmlOutput = new BufferedReader(new InputStreamReader(dt.getDataSource().getInputStream())).lines()
					.collect(Collectors.joining("\n"));
			log.info("xmlOutput:::::" + xmlOutput);

			// xml to JsonObject
			JSONObject xmlJSONObj = XML.toJSONObject(xmlOutput);

			System.out.println("xmlJSONObj::::::" + xmlJSONObj);
			JSONArray arr = xmlJSONObj.getJSONObject("DATA_DS").getJSONArray("G_1");

			String columnName = "";
			StringBuffer sb = new StringBuffer("Select ");
			for (int i = 0; i < arr.length(); i++) {
				columnName = arr.getJSONObject(i).getString("COLUMN_NAME");
				sb.append(columnName);
				if (i != arr.length() - 1)
					sb.append(",");
			}
			sb.append("  " + subQuery);
			dynamicSqlQuery = sb.toString();

			// Service call for deleting Data Model
			if (tempDataModelUrl != null && tempDataModelUrl != "") {
				log.info("tempDataModelUrl:::::::" + tempDataModelUrl + "loginResponseToken:::::::::::"
						+ loginResponseToken);
				boolean deleteTmpDataModelResp = LoginCreateDataModelHelper.deleteObject(catalogStub, tempDataModelUrl,
						loginResponseToken);
				log.info("deleteTmpDataModelResp Response::::" + deleteTmpDataModelResp);
			}
			// Service call for deleting Report
			if (tempCreateReportResponse != null && tempCreateReportResponse != "") {
				boolean deleteTmpReportResp = LoginCreateDataModelHelper.deleteObject(catalogStub,
						tempCreateReportResponse, loginResponseToken);
				log.info("deletedTempReport Response::::" + deleteTmpReportResp);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			if (tempDataModelUrl != null && tempDataModelUrl != "") {
				log.info("tempDataModelUrl:::::::" + tempDataModelUrl + "loginResponseToken:::::::::::"
						+ loginResponseToken);
				// Service call for deleting Data Model
				boolean deleteDataModelResp = LoginCreateDataModelHelper.deleteObject(catalogStub, tempDataModelUrl,
						loginResponseToken);
				log.info("deletedDataModel Response::::" + deleteDataModelResp);
			}
			if (tempCreateReportResponse != null && tempCreateReportResponse != "") {
				// Service call for deleting Report
				boolean deleteReportResp = LoginCreateDataModelHelper.deleteObject(catalogStub,
						tempCreateReportResponse, loginResponseToken);
				log.info("deletedReport Response::::" + deleteReportResp);
			}
			throw new Exception();
		}
		return dynamicSqlQuery;
	}

	public static String modifyQuery(String query) throws Exception {
		String subString="";
		try {
			String sqlQuery = query.toUpperCase();
			log.info("sqlQuery##########" + sqlQuery);
			log.info(sqlQuery.indexOf("SELECT"));
			if(sqlQuery.contains("DISTINCT"))
				 subString = sqlQuery.substring(sqlQuery.indexOf("DISTINCT") + 8, sqlQuery.indexOf("FROM")).trim();
			else
			 subString = sqlQuery.substring(sqlQuery.indexOf("SELECT") + 6, sqlQuery.indexOf("FROM")).trim();
			log.info("subString:::::"+subString);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
		return subString;
	}

	public static String converStringArrtoString(String[] strArr) throws Exception {
		StringBuilder sb = new StringBuilder();
		try {
			for (String s : strArr)
				sb.append(s).append(",");
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
		return sb.substring(0,sb.length()-1);
	}
	
	public static String convertingJsontoCsv(String jsonPrettyPrintString, String requestId, String dynamicQuery) throws Exception {
		
		JSONObject output = new JSONObject(jsonPrettyPrintString);
		JSONArray arr = null;
		JSONObject g1Obj = null;
		String csv = "";
		JSONObject dataDsObj = output.optJSONObject("DATA_DS");
		if (dataDsObj != null)
			arr = dataDsObj.optJSONArray("G_1");
		if (dataDsObj != null)
			g1Obj = dataDsObj.optJSONObject("G_1");
		System.out.println(arr + "arr::::::::");
		System.out.println(g1Obj + "g1Obj:::::::::;");
		File file = new File(requestId + ".csv");
		if (arr != null) {
			csv = CDL.toString(arr);
		} else if (g1Obj != null) {
			JSONArray jsonArr = new JSONArray();
			jsonArr.put(g1Obj);
			// System.out.println("enetringesifffffff::::::");
			// csv=g1Obj.toString();
			csv = CDL.toString(jsonArr);
			// System.out.println(csv+":::::::::csv");
		} else {
			// System.out.println("enetringesleeeeeeee:::::::");
			csv = modifyQuery(dynamicQuery);
			System.out.println(csv + ":::::::::csv");
			if (csv.contains(".")) {
				String[] columnNames = csv.split(",");
				StringBuffer sb=new StringBuffer();
				for (int i=0;i<columnNames.length;i++) {
					if (columnNames[i].contains(".")) {
						String[] columnNameArr = columnNames[i].split("\\.");
						columnNames[i] = columnNameArr[1];
						sb.append(columnNames[i]);
						if(i!=columnNames.length-1)
							sb.append(",");	
					}
				}
				csv=sb.toString();
			}
		}
		
		return csv;
	}

}
