package com.rite.products.cloudconnector.security;

public class CloudDataProcessPo {

	private String requestId;
	private String lookUpFlag;
	private String sqlQuery;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getLookUpFlag() {
		return lookUpFlag;
	}

	public void setLookUpFlag(String lookUpFlag) {
		this.lookUpFlag = lookUpFlag;
	}

	public String getSqlQuery() {
		return sqlQuery;
	}

	public void setSqlQuery(String sqlQuery) {
		this.sqlQuery = sqlQuery;
	}

}
