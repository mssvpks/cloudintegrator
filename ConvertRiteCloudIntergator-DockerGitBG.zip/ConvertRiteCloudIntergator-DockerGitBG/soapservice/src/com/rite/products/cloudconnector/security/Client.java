package com.rite.products.cloudconnector.security;

import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

import com.rite.products.cloudconnector.catalog.CatalogServiceStub;

public class Client {

	static final Logger log = Logger.getLogger(Client.class);

	public static void main(String[] args) throws Exception {
		while (true) {
			Connection con = null;

			try {
				log.info("start##");
				Properties props = LoginCreateDataModelHelper.loadProperties();
				// ResultSet rs = null;
				ResultSet resultSet = null;

				// Create Connection
				con = DataSourceUtil.createConnection();

				// create the statement object
				PreparedStatement stmt = con.prepareStatement(
						"select * from XXR_CLOUD_DATA_PROCESS where status='Starting' order by priority desc");
				// execute query
				ResultSet rset = stmt.executeQuery();

				// cloudTest Instance information fetching
				PreparedStatement cloudDataConfigStmnt = con
						.prepareStatement("select * from XXR_CLOUD_DATA_PROCESS_CONFIG");
				resultSet = cloudDataConfigStmnt.executeQuery();

				String userName = "";
				String password = "";
				String soapUrl = "";
				if (resultSet.next()) {
					log.info("Inside if ###");
					userName = resultSet.getString("USER_NAME");
					password = resultSet.getString("PASSWORD");
					soapUrl = resultSet.getString("CLOUD_URL");
					log.info("soapUrl#####" + soapUrl);
				}

				String url = soapUrl;
				String usrName = userName;
				String pswd = password;
				Connection c = con;
				cloudDataConfigStmnt.close();
				int threadNum = 5;
				int totalCount = 0;
				List<CloudDataProcessPo> cldReqPoLi = new ArrayList<>();

				while (rset.next()) {
					CloudDataProcessPo cloudDataProcessPo = new CloudDataProcessPo();
					totalCount++;
					log.info("Inside while loop##");
					String requestId = rset.getString("REQUEST_ID");
					String lookupFlag = rset.getString("LOOKUP_FLAG");
					log.info("requestId##### " + requestId);
					String dynamicSqlQuery = rset.getString("SQLQUERY");
					log.info("dynamicSqlQuery:::" + dynamicSqlQuery);

					cloudDataProcessPo.setRequestId(requestId);
					cloudDataProcessPo.setLookUpFlag(lookupFlag);
					cloudDataProcessPo.setSqlQuery(dynamicSqlQuery);

					cldReqPoLi.add(cloudDataProcessPo);
				}

				ExecutorService executor = Executors.newFixedThreadPool(threadNum);
				List<Future<Integer>> taskList = new ArrayList<Future<Integer>>();
				double loopCount = Math.ceil((double) cldReqPoLi.size() / (double) threadNum);
				log.info("cldReqPoLi.size()" + cldReqPoLi.size());
				log.info("loopCount::::::" + loopCount);
				// int threadCount=threadNum;

				for (int j = 0; j < loopCount; j++) {
					if (j == loopCount - 1)
						threadNum = cldReqPoLi.size() % threadNum;
					if (threadNum == 0)
						threadNum = 5;
					
					for (int i = j*5; i < j*5+threadNum; i++) {
						Callable<Integer> myCallable = new ProcessCallable(cldReqPoLi.get(i), url, usrName, pswd, c);
						Future<Integer> futureTask_1 = executor.submit(myCallable);
						taskList.add(futureTask_1);
					}

					
				}
				log.info(taskList.size() + "::::::::::size");

				log.info("entering::");
				executor.shutdown();
				try {
					executor.awaitTermination(1, TimeUnit.DAYS);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				stmt.close();

				if (totalCount == 0) {
					log.info("Thread Sleeping ###");
					Thread.sleep(Long.parseLong(props.getProperty("thread-sleep-time")));
				}
			} catch (Exception e) {
				e.printStackTrace();

			} finally {
				if (con != null)
					con.close();
			}
		}
	}

	public static int processRequests(String requestId, String lookupFlag, String dynamicSqlQuery, String soapUrl,
			String userName, String password, Connection con) throws Exception {
		String dataModelUrl = "";
		String loginResponseToken = "";
		String createReportResponse = "";
		CatalogServiceStub catalogStub = null;
		int totalCount = 0;
		Properties props = LoginCreateDataModelHelper.loadProperties();
		try {
			PreparedStatement updateStatus = con.prepareStatement(
					"update XXR_CLOUD_DATA_PROCESS set status='processing' where request_id='" + requestId + "'");
			int count = updateStatus.executeUpdate();

			log.info("No of rows updated :::::" + count);

			updateStatus.close();
			// Authentication service
			loginResponseToken = LoginCreateDataModelHelper.loginService(soapUrl, userName, password);
			log.info("authenticationToken:::::" + loginResponseToken);

			catalogStub = new CatalogServiceStub(soapUrl + props.getProperty("catalog-service-url"));

			// generating dynamic query with column names instead of "*"
			if (dynamicSqlQuery.contains("*")) {
				dynamicSqlQuery = Utils.generateDynamicSqlQuery(dynamicSqlQuery, catalogStub, soapUrl,
						loginResponseToken);
			}
			// Service call for creating DataModel in Cloud
			dataModelUrl = LoginCreateDataModelHelper.createDataModel(catalogStub, requestId, loginResponseToken,
					dynamicSqlQuery);
			log.info("dataModelUrl:::::" + dataModelUrl);

			// Service call for creating report
			createReportResponse = ReportHelper.createReportService(soapUrl, loginResponseToken, requestId,
					dataModelUrl);
			log.info("createReportResponse:::::::::::" + createReportResponse);

			// service call to RunReport
			DataHandler dt = ReportHelper.runReport(soapUrl, loginResponseToken, createReportResponse);

			String xmlOutput = IOUtils.toString(dt.getDataSource().getInputStream(), "UTF-8");
			/*
			 * String xmlOutput = new BufferedReader( new
			 * InputStreamReader(dt.getDataSource().getInputStream())).lines()
			 * .collect(Collectors.);
			 */
			log.info("xmlOutput:::::" + xmlOutput);

			int PRETTY_PRINT_INDENT_FACTOR = 4;

			// xml to JsonObject
			JSONObject xmlJSONObj = XML.toJSONObject(xmlOutput);
			log.info("xmlJSONObj:::::::" + xmlJSONObj);
			if (lookupFlag != null && lookupFlag != "") {
				if (lookupFlag.equalsIgnoreCase("Y"))
					insertIntoLookup(xmlJSONObj, con);
			}
			String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
			log.info("jsonPrettyPrintString:::::::" + jsonPrettyPrintString);

			/*
			 * // Json & csv File Transfer to RemoteLocation
			 * FileTransferHelper.fileTransfer(jsonPrettyPrintString, requestId,
			 * dynamicSqlQuery);
			 */
			
			//converting Json String to csv string format
			String csv=Utils.convertingJsontoCsv(jsonPrettyPrintString,requestId,dynamicSqlQuery);
			//saving csv string as lob
			csv=csv.replaceAll("\\'", "''");
			PreparedStatement saveLob = con
					.prepareStatement("insert into  XXR_BLOB_CONVERRITE(ID,BLOB_TYPE,BLOB_NAME,Blob) values('"
							+ requestId + "','csv','"+requestId+".csv',?)");
			
			  Clob myClob = con.createClob();
			  myClob.setString( 1, csv); 
			  saveLob.setClob(1,myClob);
			 
			int rowsInserted=saveLob.executeUpdate();
			
			log.info("No of rows inserted :::::" + rowsInserted);
			
			// create the statement object
			PreparedStatement updateStmnt = con
					.prepareStatement("update XXR_CLOUD_DATA_PROCESS set status='completed' where request_id='"
							+ requestId + "'");

			int rowsUpdated = updateStmnt.executeUpdate();

			log.info("No of rows updated :::::" + rowsUpdated);

			//log.info("completed writing data to json file");

			// Service call for deleting Data Model
			boolean deleteDataModelResp = LoginCreateDataModelHelper.deleteObject(catalogStub, dataModelUrl,
					loginResponseToken);
			log.info("deletedDataModel Response::::" + deleteDataModelResp);

			// Service call for deleting Report
			boolean deleteReportResp = LoginCreateDataModelHelper.deleteObject(catalogStub, createReportResponse,
					loginResponseToken);
			log.info("deletedReport Response::::" + deleteReportResp);
		} catch (Exception e) {
			PreparedStatement updateStmnt = con.prepareStatement(
					"update XXR_CLOUD_DATA_PROCESS set status='error'" + " where request_id='" + requestId + "'");
			int rowsUpdated = updateStmnt.executeUpdate();
			log.info("No of rows updated :::::" + rowsUpdated);
			if (dataModelUrl != null && dataModelUrl != "") {
				log.info("dataModelUrl:::::::" + dataModelUrl + "loginResponseToken:::::::::::" + loginResponseToken);
				// Service call for deleting Data Model
				boolean deleteDataModelResp = LoginCreateDataModelHelper.deleteObject(catalogStub, dataModelUrl,
						loginResponseToken);
				log.info("deletedDataModel Response::::" + deleteDataModelResp);
			}
			if (createReportResponse != null && createReportResponse != "") {
				// Service call for deleting Report
				boolean deleteReportResp = LoginCreateDataModelHelper.deleteObject(catalogStub, createReportResponse,
						loginResponseToken);
				log.info("deletedReport Response::::" + deleteReportResp);
			}
			e.printStackTrace();
		}

		return totalCount;
	}

	private static void insertIntoLookup(JSONObject xmlJSONObj, Connection con) {
		System.out.println(xmlJSONObj.toString());

		JSONObject dataDsObj = xmlJSONObj.optJSONObject("DATA_DS");
		JSONArray arr = null;
		JSONObject g1Obj = null;
		if (dataDsObj != null)
			arr = dataDsObj.optJSONArray("G_1");

		// JSONArray arr = xmlJSONObj.getJSONObject("DATA_DS").getJSONArray("G_1");

		String lookupType = "";
		String lookupCode = "";
		// ResultSet set = null;
		ResultSet rs = null;
		// ResultSet result = null;
		ResultSet lookupCodeSet = null;
		PreparedStatement lookupsetSelect = null;
		// PreparedStatement lookupset = null;
		// PreparedStatement lookupValueSelect = null;
		PreparedStatement lookupCodeSelect = null;
		if (dataDsObj != null)
		g1Obj = dataDsObj.optJSONObject("G_1");
		if (g1Obj != null) {
			arr = new JSONArray();
			arr.put(g1Obj);
		}
		if (arr != null) {
			for (int i = 0; i < arr.length(); i++) {

				try {

					lookupType = arr.getJSONObject(i).getString("LOOKUP_TYPE");
					log.info("lookupType::::::::::" + lookupType);

					Object lookupCodeObj = arr.getJSONObject(i).get("LOOKUP_CODE");
					log.info("lookupCodeObj::::::::::" +  String.valueOf(lookupCodeObj));
					
					lookupCode=String.valueOf(lookupCodeObj);
					
					/*
					 * if (lookupCodeObj instanceof Integer) lookupCode = Integer.toString(((Number)
					 * (lookupCodeObj)).intValue()); if (lookupCodeObj instanceof String) lookupCode
					 * = lookupCodeObj.toString();
					 */

					lookupsetSelect = con.prepareStatement(
							"Select * from xxr_lookup_sets where lookup_set_name='" + lookupType + "'");
					rs = lookupsetSelect.executeQuery();
					Long lookupSetId = null;
					if (rs.next()) {
						lookupSetId = new BigDecimal(rs.getString("lookup_set_id")).longValue();
					} else {

						PreparedStatement lookupsetInsert = con.prepareStatement(
								"Insert into xxr_lookup_sets (lookup_set_id,lookup_set_name,last_updated_by,last_update_date) values (xxr_lookup_set_id_s.nextval,'"
										+ lookupType + "','ConvertRite',sysdate)");
						lookupsetInsert.executeUpdate();
						lookupsetInsert.close();
						rs = lookupsetSelect.executeQuery();
						if (rs.next()) {
							lookupSetId = new BigDecimal(rs.getString("lookup_set_id")).longValue();
						}
					}

					if (lookupSetId != null) {
						lookupCodeSelect = con
								.prepareStatement("select * from  xxr_lookup_values where lookup_set_id=" + lookupSetId
										+ " and  lookup_value='" + lookupCode + "' order by lookup_value_id desc");

						lookupCodeSet = lookupCodeSelect.executeQuery();

						Long lookUpId = null;
						if (lookupCodeSet.next()) {
							lookUpId = new BigDecimal(lookupCodeSet.getString("LOOKUP_VALUE_ID")).longValue();

						}
						log.info("lookUpId:::::::::" + lookUpId);
						if (lookUpId == null) {
							PreparedStatement lookupValueInsert = con.prepareStatement(
									"Insert into xxr_lookup_values(lookup_set_id,lookup_value_id,lookup_value,last_updated_by,last_update_date) values("
											+ lookupSetId + ", xxr_lookup_value_id_s.nextval,'" + lookupCode
											+ "','ConvertRite',sysdate)");
							lookupValueInsert.executeUpdate();
							lookupValueInsert.close();
						}
						/*
						 * lookupValueSelect =
						 * con.prepareStatement("select * from  xxr_lookup_values where lookup_set_id="
						 * + lookupSetId + "order by lookup_value_id desc");
						 * 
						 * set = lookupValueSelect.executeQuery();
						 * 
						 * Long lookUpValueId = null; if (set.next()) { lookUpValueId = new
						 * BigDecimal(set.getString("LOOKUP_VALUE_ID")).longValue(); } if (lookUpValueId
						 * != null) {
						 * 
						 * lookUpValueId = (long) lookUpValueId + 1;
						 * 
						 * lookupCodeSelect = con
						 * .prepareStatement("select * from  xxr_lookup_values where lookup_set_id=" +
						 * lookupSetId + " and  lookup_value='" + lookupCode +
						 * "' order by lookup_value_id desc");
						 * 
						 * lookupCodeSet = lookupCodeSelect.executeQuery();
						 * 
						 * Long lookUpId = null; if (lookupCodeSet.next()) { lookUpId = new
						 * BigDecimal(lookupCodeSet.getString("LOOKUP_VALUE_ID")).longValue();
						 * 
						 * } log.info("lookUpId:::::::::" + lookUpId); if (lookUpId == null) {
						 * PreparedStatement lookupValueInsert = con.prepareStatement(
						 * "Insert into xxr_lookup_values(lookup_set_id,lookup_value_id,lookup_value,last_updated_by,last_update_date) values("
						 * + lookupSetId + "," + lookUpValueId + ",'" + lookupCode +
						 * "','ConvertRite',sysdate)"); lookupValueInsert.executeUpdate();
						 * lookupValueInsert.close(); } } else { PreparedStatement lookupValueInsert =
						 * con.prepareStatement(
						 * "Insert into xxr_lookup_values(lookup_set_id,lookup_value_id,lookup_value,last_updated_by,last_update_date) values("
						 * + lookupSetId + ",1,'" + lookupCode + "','ConvertRite',sysdate)");
						 * lookupValueInsert.executeUpdate(); lookupValueInsert.close(); }
						 */

					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					// throw new Exception();

				} finally {
					try {

						if (rs != null)
							rs.close();
						/*
						 * if (set != null) set.close(); if (result != null) result.close();
						 */
						if (lookupCodeSet != null)
							lookupCodeSet.close();
					} catch (SQLException ex) {
						ex.getMessage();
					}
					try {
						if (lookupsetSelect != null)
							lookupsetSelect.close();
						/*
						 * if (lookupset != null) lookupset.close(); if (lookupValueSelect != null)
						 * lookupValueSelect.close();
						 */
						if (lookupCodeSelect != null)
							lookupCodeSelect.close();
					} catch (SQLException ex) {
						ex.getMessage();
					}
				}
			}
		}
	}

}

class ProcessCallable implements Callable<Integer> {
	private CloudDataProcessPo cldDataProcessPo;
	private String url;
	private String usrName;
	private String pswd;
	private Connection c;
	static final Logger logger = Logger.getLogger(ProcessCallable.class);

	public ProcessCallable(CloudDataProcessPo cldDataProcessPo, String url, String usrName, String pswd, Connection c) {
		this.cldDataProcessPo = cldDataProcessPo;
		this.url = url;
		this.usrName = usrName;
		this.pswd = pswd;
		this.c = c;
	}

	@Override
	public Integer call() throws Exception {
		int totalCount = 0;
		logger.info(Thread.currentThread().getName() + "::::Thread-Name");
		totalCount = Client.processRequests(cldDataProcessPo.getRequestId(), cldDataProcessPo.getLookUpFlag(),
				cldDataProcessPo.getSqlQuery(), url, usrName, pswd, c);
		return totalCount;

	}
}