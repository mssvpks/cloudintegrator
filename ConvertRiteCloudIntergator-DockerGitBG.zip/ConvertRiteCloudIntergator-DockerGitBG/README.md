# ConvertRiteCloudIntergator
Cloud integration with Oracle using SOAP and REST end points of Oracle fusion, BI publisher and Oracle Cloud
